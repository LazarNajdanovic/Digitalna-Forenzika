﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;


namespace DigitalnaForenzika
{
  public class Program
  {
    public static Bitmap EncodeMessageIntoImage(Bitmap image, string message)
    {
      byte[] messageBytes = Encoding.UTF8.GetBytes(message);
      int messageLength = messageBytes.Length;

      if (messageLength * 8 > image.Width * image.Height)
      {
        throw new ArgumentException("Message length is to big for saving into image.");
      }

      BitmapData bitmapData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);

      int stride = bitmapData.Stride;
      IntPtr ptr = bitmapData.Scan0;
      int bytesPerPixel = 3;
      int totalBytes = stride * image.Height;
      byte[] pixelData = new byte[totalBytes];
      Marshal.Copy(ptr, pixelData, 0, totalBytes);

      int byteIndex = 0;
      int bitIndex = 0;
      for (int i = 0; i < pixelData.Length; i += bytesPerPixel)
      {
        if (byteIndex >= messageBytes.Length)
        {
          break;
        }

        int bit = (messageBytes[byteIndex] >> bitIndex) & 1;

        pixelData[i] = (byte)((pixelData[i] & 0xFE) | bit);

        bitIndex++;
        if (bitIndex == 8)
        {
          bitIndex = 0;
          byteIndex++;
        }
      }

      Marshal.Copy(pixelData, 0, ptr, totalBytes);
      image.UnlockBits(bitmapData);
      return image;
    }

    public static string DecodeMessageFromImage(Bitmap image, int messageLength)
    {
      BitmapData bitmapData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);

      int stride = bitmapData.Stride;
      IntPtr ptr = bitmapData.Scan0;
      int bytesPerPixel = 3; 
      int totalBytes = stride * image.Height;

      byte[] pixelData = new byte[totalBytes];
      Marshal.Copy(ptr, pixelData, 0, totalBytes);

      byte[] messageBytes = new byte[messageLength];
      int byteIndex = 0;
      int bitIndex = 0;

      for (int i = 0; i < pixelData.Length; i += bytesPerPixel)
      {
        if (byteIndex >= messageLength)
        {
          break; 
        }

        int bit = pixelData[i] & 1;
        messageBytes[byteIndex] |= (byte)(bit << bitIndex);

        bitIndex++;
        if (bitIndex == 8)
        {
          bitIndex = 0;
          byteIndex++;
        }
      }

      image.UnlockBits(bitmapData);
      return Encoding.UTF8.GetString(messageBytes);
    }


    public static Bitmap ConvertTo24bppRgb(Bitmap originalImage)
    {
      Bitmap newImage = new Bitmap(originalImage.Width, originalImage.Height, PixelFormat.Format24bppRgb);

      using (Graphics g = Graphics.FromImage(newImage))
      {
        g.DrawImage(originalImage, 0, 0, originalImage.Width, originalImage.Height);
      }
      return newImage;
    }

    public static void Main(string[] args)
    {
      Bitmap originalImage = (Bitmap)Image.FromFile("C:\\Users\\Najdanovic\\source\\repos\\DigitalnaForenzika\\DigitalnaForenzika\\TEST3.jpg");
      string message = "Secret";

      var convertedImage = ConvertTo24bppRgb(originalImage);

      Bitmap imageWithHiddenMessage = EncodeMessageIntoImage(convertedImage, message);
      imageWithHiddenMessage.Save("C:\\Users\\Najdanovic\\source\\repos\\DigitalnaForenzika\\DigitalnaForenzika\\test2.png");



      Bitmap hiddenImage = (Bitmap)Image.FromFile("C:\\Users\\Najdanovic\\source\\repos\\DigitalnaForenzika\\DigitalnaForenzika\\test2.png");
      string decodedMessage = DecodeMessageFromImage(hiddenImage, message.Length);
      Console.WriteLine(decodedMessage);
    }    
  }
}
